package main

import (
	"fmt"
	"sync"
	"time"
)

type atomicInt struct {
	value int
	lock sync.Mutex
}

func (atomic *atomicInt) increment(){
	atomic.lock.Lock()
	defer atomic.lock.Unlock()
	atomic.value++
}

func (atomic *atomicInt) get() int{
	atomic.lock.Lock()
	defer atomic.lock.Unlock()   //资源管理关闭用defer
	return atomic.value
}

func main() {
	//atomic.AddInt32()   系统提供的线程安全方法
	var i atomicInt
	i.increment()
	go func() {
		i.increment()
	}()
	time.Sleep(time.Millisecond)
	fmt.Println(i.get())
}
