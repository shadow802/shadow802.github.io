package main

import (
	"fmt"
	"math/rand"
	"time"
)

func generator() chan int{
	c := make(chan int)
	i := 0
	go func() {
		for{
			c <- i
			i++
			time.Sleep(time.Duration(rand.Intn(1000)) * time.Millisecond)
		}

	}()
	return c
}

func doWork(id int, c chan int){
	for v := range c {
		time.Sleep(time.Second)
		fmt.Printf("worker range channel %d received %d \n", id, v)
	}
}


func worker(id int) chan<- int{
	c := make(chan int)
	go doWork(id, c)
	return c
}

func main() {

	var c1, c2 = generator(), generator()
	var values []int

	worker := worker(999)

	after := time.After(10 * time.Second)
	tick := time.Tick(time.Second)

	for{
		var value int
		var execute chan<- int
		if len(values) > 0{
			//当有需要消费的数据的时候，赋值消费者channel。
			value = values[0]
			execute = worker
		}
		select {
		case n := <- c1:
			fmt.Printf("c1 received %d \n", n)
			values = append(values, n)
		case n := <- c2:
			fmt.Printf("c2 received %d \n", n)
			values = append(values, n)
		case execute <- value :   //nil channel是可以 在select中正确运行的，只不过永远是阻塞的
			values = values[1:]
		case <- after:
			fmt.Println("bye bye")
			return
		case <- tick:
			fmt.Printf("queue length %d \n", len(values))
		}
	}
}
