package main

import (
	"fmt"
	"sync"
)

type workChan struct {
	in chan int
	done func()
}

func doWork(id int, w workChan){
	for v := range w.in {
		fmt.Printf("worker %d received %c \n", id, v)
		w.done()
	}
}

func worker(id int, wg *sync.WaitGroup) workChan{
	w := workChan{
		in: make(chan int),
		done: func() {
			wg.Done()
		},
	}
	go doWork(id, w)
	return w
}

func main() {
	var c [10]workChan
	var wg sync.WaitGroup

	for i := 0; i < 10; i++ {
		c[i] = worker(i, &wg)
	}

	//发送任务
	for i := range c {
		wg.Add(1)
		c[i].in <- 'a' + i
	}

	for i := range c {
		wg.Add(1)
		c[i].in <- 'A' + i
	}

	//统一等待所有的任务结束
	wg.Wait()

}
