package main

import (
	"fmt"
	"time"
)

func doWork(id int, c chan int){
	for {
		n, ok := <-c
		if !ok {
			break
		}
		//I/O 操作，go的调度器会发生调度
		fmt.Printf("worker <-c  %d received %d \n", id, n)
	}

	//channel 不关闭，它就可以一直收
	for v := range c {
		fmt.Printf("worker range channel %d received %d \n", id, v)
	}
}

//给chan一个方向，
//代表该channel只可以往channel发送数据（chan<-）
//或者只可以从channel接收数据（->chan）
func worker(id int) chan<- int{
	c := make(chan int)
	go doWork(id, c)
	return c
}


func channelDemo(){
	//var c chan int // c == nil
	var channels [10]chan<- int
	for i := 0; i < 10; i++ {
		//必须要有一个接收的goroutine，否则会发生deadlock
		channels[i] = worker(i)

		//发送数据到对应的channel
		channels[i] <- 'A' + i
		channels[i] <- i
		channels[i] <- 'a' + i
	}

}


func bufferedChannel(){
	c := make(chan int, 2) //加一个缓冲区大小，可以连续发送数据，而不出现deadlock，减少协程的切换

	c <- 22
	c <- 33

	//超过缓冲区大小2，如果没有接受的goroutine 依然会报错
	go doWork(100, c)
	c <- 44
}

func channelClose(){
	c := make(chan int, 2)

	c <- 122
	c <- 233

	//超过缓冲区大小2，如果没有接受的goroutine 依然会报错
	go doWork(200, c)
	c <- 344
	close(c)   //使用了channel close 可以配合range来取用channel的值
}

func main() {

	channelDemo()

	bufferedChannel()

	channelClose()

	//如果来不及打印，需要等待一段时间~~不一定出现，要看执行的效率，后续优化掉这里
	time.Sleep(time.Millisecond)
}
