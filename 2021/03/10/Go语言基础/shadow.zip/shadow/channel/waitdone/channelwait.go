package main

import "fmt"

type workChan struct {
	in chan int
	done chan bool
}

func doWork(id int, in chan int, done chan bool){
	for v := range in {
		fmt.Printf("worker %d received %c \n", id, v)
		go func() {
			done <- true
		}()  //这里channel是阻塞的，前一个done没有处理，不能发送后一个
	}
}

func worker(id int) workChan{
	w := workChan{
		in: make(chan int),
		done: make(chan bool),
	}
	go doWork(id, w.in, w.done)
	return w
}

func main() {
	var c [10]workChan
	for i := 0; i < 10; i++ {
		c[i] = worker(i)
	}

	//发送任务
	for i := range c {
		c[i].in <- 'a' + i
		//<- c[i].done
	}

	for i := range c {
		c[i].in <- 'A' + i
		//<- c[i].done  这样失去了并行的意义
	}

	//统一等待所有的任务结束
	for _, work := range c {
		<-work.done
		<-work.done
	}

}
