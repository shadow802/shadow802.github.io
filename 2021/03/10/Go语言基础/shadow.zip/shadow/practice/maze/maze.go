package main

import (
	"fmt"
	"os"
)

func createArray2(row, col int) [][]int{
	array2 := make([][]int, row)
	for i := range array2{
		array2[i] = make([]int, col)
	}
	return array2
}

func readMaze(filename string) [][]int{
	file, err := os.Open(filename)
	if err != nil {
		panic(err)
	}
	var row, col int
	fmt.Fscanf(file, "%d %d", &row, &col)
	maze := createArray2(row, col)
	for i := range maze {
		for j := range maze[i] {
			fmt.Fscanf(file, "%d", &maze[i][j])
		}
	}
	return maze
}

type point struct {
	i,j int
}

var direction = []point{
	{-1,0},{0,-1},{0,1},{1,0},
}

func (p point)directTo(r point) point{
	return point{p.i + r.i, p.j + r.j}
}

func walk(maze [][]int, start, end point) [][]int{
	queue := []point{start}

	steps := createArray2(len(maze), len(maze[0]))

	for len(queue) > 0 {
		current := queue[0]
		queue = queue[1:]

		for _,r := range direction{
			next := current.directTo(r)
			//不在范围内的点
			if next.i < 0 || next.i >= len(maze) || next.j < 0 || next.j >=len(maze[next.i]){
				continue
			}
			//在墙上的点
			if maze[next.i][next.j] == 1{
				continue
			}
			//已经寻过的点
			if steps[next.i][next.j] != 0 {
				continue
			}
			//找回起点
			if next.i == start.i && next.j == start.j {
				continue
			}
			queue = append(queue, next)
			steps[next.i][next.j] = steps[current.i][current.j] + 1
			//到达终点
			if next.i == end.i && next.j == end.j {
				return steps
			}
		}

	}
	return steps
}


func findMinPath(steps [][]int, start, end point) []point{
	min := []point{end}
	minSteps := steps[end.i][end.j]

	for {
		for _,v := range direction {
			next := end.directTo(v)
			//不在范围内的点
			if next.i < 0 || next.i >= len(steps) || next.j < 0 || next.j >=len(steps[next.i]){
				continue
			}
			//找到其中一条通路，这里可能有多条路线。
			if steps[next.i][next.j] == minSteps - 1 {
				min = append(min, next)
				end = next
				minSteps--
			}
			//找到起点了
			if next.i == start.i && next.j == start.j {
				return min
			}
		}

	}

	return min
}


func main() {
	//这里有个换行符的问题，在windows下换行为/r/n fmt.Fscanf会将\r读成0需要转换成linux下的换行符\n
	maze := readMaze("practice/maze/maze.in")
	fmt.Println("-- maze data --")
	for i := range maze {
		fmt.Println(maze[i])
	}
	fmt.Println("-- maze data --")


	start, end := point{0, 0}, point{5, 4}
	steps := walk(maze, start, end)

	fmt.Println("-- steps data --")
	for i := range steps {
		fmt.Println(steps[i])
	}
	fmt.Println("-- steps data --")

	fmt.Println(findMinPath(steps, start, end))
}
