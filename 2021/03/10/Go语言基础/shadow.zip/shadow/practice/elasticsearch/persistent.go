package main

import (
	"context"
	"encoding/json"
	"fmt"
	"github.com/olivere/elastic"
)

// 要序列化，属性首字母必须得大写，也就是说要是公共的。
type DataBO struct {
	Name string  `json:"name"`
	Age int	     `json:"age"`
	Region string `json:"region"`
	Url string `json:"url"`
}

var client, _ = elastic.NewClient(elastic.SetSniff(false))

//ES7将Type设计将要废弃的状态，默认一个index下只有一个doc的type
func saveData(data interface{}) (id string, err error){
	resp, err := client.Index().Index("108").BodyJson(data).Do(context.Background())
	if err != nil {
		return "", err
	}

	fmt.Printf("%+v", resp)

	return resp.Id,nil
}

func getData(id string) (data DataBO, err error){
	resp, err := client.Get().Index("108").Id(id).Do(context.Background())
	if err != nil {
		return DataBO{}, err
	}

	var result DataBO
	json.Unmarshal(resp.Source, &result)

	return result, nil
}

func main()  {
	saveData(DataBO{
		Name: "shadow108",
		Age: 12,
		Region: "QingDao",
		Url: "https://www/baidu.com",
	})
}