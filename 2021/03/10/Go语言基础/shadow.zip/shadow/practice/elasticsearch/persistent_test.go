package main

import "testing"

func TestSaveData(t *testing.T) {

	data := DataBO{
		Name: "xxxxx",
		Age: 12,
		Region: "QingDao",
		Url: "https://www/baidu.com",
	}

	id, err := saveData(data)
	if err != nil {
		t.Errorf("save data error %v", err)
	}

	result, err := getData(id)
	if err != nil {
		t.Errorf("get data error %v", err)
	}

	if data != result{
		t.Errorf("expeted %v , but got %v", data, result)
	}
}
