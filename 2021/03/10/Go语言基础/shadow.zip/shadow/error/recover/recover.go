package main

import (
	"errors"
	"fmt"
)

func tryRecover(){

	defer func() {
		err := recover()
		if r, ok := err.(error); ok{
			fmt.Println(r)
		}else{
			panic(err)
		}
	}()

	panic(errors.New("error"))

}

func main() {
	tryRecover()
}
