package main

import (
	"log"
	"net/http"
	"os"
	"shadow/error/web/handler"
)

//使用者定义接口
type userError interface {
	error
	Message() string
}

func wrapError(handler func(writer http.ResponseWriter, request *http.Request) error) func(writer http.ResponseWriter, request *http.Request){
	return func(writer http.ResponseWriter, request *http.Request) {
		//处理handler panic出的异常
		defer func() {
			if r := recover(); r != nil{
				log.Printf("unexpected panic error : %s\n", r)
				http.Error(writer,
					http.StatusText(http.StatusInternalServerError),
					http.StatusInternalServerError)
			}
		}()

		err := handler(writer, request)

		//增加对用户异常的处理
		if ue, ok := err.(userError); ok{
			log.Printf("unexpected panic error : %s\n", ue)
			http.Error(writer,
				ue.Message(),
				http.StatusBadRequest)

			return
		}

		code := http.StatusOK
		if err != nil {
			log.Printf("error occured : %s\n" , err)
			switch {
			case os.IsNotExist(err):
				code = http.StatusNotFound
			case os.IsPermission(err):
				code = http.StatusForbidden
			default:
				code = http.StatusInternalServerError
			}
			http.Error(writer, http.StatusText(code), code)
		}
	}
}

func main() {

	//http.HandleFunc("/file/list/",
	//	func(writer http.ResponseWriter, request *http.Request) {
	//		path := request.URL.Path[len("/file/list/"):]
	//		file, err := os.Open(path)
	//		defer file.Close()
	//		if err != nil{
	//			panic(err)
	//		}
	//		content, err := ioutil.ReadAll(file)
	//		if err != nil{
	//			panic(err)
	//		}
	//		writer.Write(content)
	//	})

	// http.HandleFunc("/file/list/", wrapError(handler.Handle)) 下面演示路径不一样出现的问题

	http.HandleFunc("/", wrapError(handler.Handle))

	err := http.ListenAndServe(":8888", nil)
	if err != nil{
		panic(err)
	}
}
