package handler

import (
	"io/ioutil"
	"log"
	"net/http"
	"os"
	"strings"
)


type uError string

//实现error接口
func (ue uError) Error() string{
	return ue.Message()
}

func (ue uError) Message() string{
	return string(ue)
}


const prefix = "/file/list/"
func Handle(writer http.ResponseWriter, request *http.Request) error{
	if strings.Index(request.URL.Path, prefix) != 0{
		log.Print("path incorrect")
		return uError("path incorrect")
	}
	path := request.URL.Path[len(prefix):]
	file, err := os.Open(path)
	defer file.Close()
	if err != nil{
		return err
	}
	content, err := ioutil.ReadAll(file)
	if err != nil{
		return err
	}
	writer.Write(content)

	return nil
}
