package main

import (
	"io/ioutil"
	"net/http"
	"net/http/httptest"
	"os"
	"strings"
	"testing"
)

type uError string

//实现error接口
func (ue uError) Error() string{
	return ue.Message()
}

func (ue uError) Message() string{
	return string(ue)
}

func errorPanic(writer http.ResponseWriter, request *http.Request) error{
	panic("panic error")
}

func errorNotFound(writer http.ResponseWriter, request *http.Request) error{
	return os.ErrNotExist
}

func errorUError(writer http.ResponseWriter, request *http.Request) error{
	return uError("custom")
}

var tests = []struct {
	handler func(writer http.ResponseWriter, request *http.Request) error
	code int
	message string
}{
	{errorPanic, 500, "Internal Server Error"},
	{errorNotFound, 404, "Not Found"},
	{errorUError, 400, "custom"},
}

//mock测试
func TestErrorWrap(t *testing.T){
	for _, v := range tests{
		f := wrapError(v.handler)
		resp := httptest.NewRecorder()
		rest := httptest.NewRequest(http.MethodGet, "http://www.baidu.com", nil)
		f(resp, rest)
		verifyResponse(resp.Result(), v, t)
	}
}

func TestWebServer(t *testing.T){
	for _, v := range tests{
		f := wrapError(v.handler)
		server := httptest.NewServer(http.HandlerFunc(f))
		resp,_ := http.Get(server.URL)
		verifyResponse(resp, v, t)
	}
}

func verifyResponse(resp *http.Response,
	v struct{
		handler func(writer http.ResponseWriter, request *http.Request) error
		code int
		message string
	},
	t *testing.T){
	b,_ := ioutil.ReadAll(resp.Body)
	body := strings.Trim(string(b), "\n")
	if resp.StatusCode != v.code || body != v.message{
		t.Errorf("expected (%d, %s), but got (%d, %s)", v.code, v.message, resp.StatusCode, body)
	}
}
