package main

import (
	"bufio"
	"fmt"
	"os"
	"shadow/functional/fib"
)

func tryDefer(){
	fib := fib.Fibonacci()
	for i:=0; i<100; i++{
		defer fmt.Printf("defer --> %d\n", i)
		if i < 30{
			fmt.Println(fib())
		}
	}
}


func fileWrite(){
	//file, err := os.Create("fib.txt")
	file, err := os.OpenFile("fib.txt", os.O_EXCL | os.O_CREATE, 0666)  //存在文件会引起异常
	//err = errors.New("custom error")  //自定义异常
	if err != nil {
		if pathErr, ok := err.(*os.PathError); !ok{
			panic(err)
		}else{
			fmt.Println(pathErr)
		}
		return
	}
	defer file.Close()

	write := bufio.NewWriter(file)
	defer write.Flush()
	fib := fib.Fibonacci()
	for i:=0; i<100; i++{
		fmt.Fprintln(write, fib())
	}
}


func main() {
	tryDefer()
	fileWrite()
}
