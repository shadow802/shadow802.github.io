package mock

import "fmt"

type TestData struct {
	Contents string
}

func (r *TestData) String() string {
	return fmt.Sprintf("contents is %s", r.Contents)
}

func (r *TestData) Post(url string, form map[string]string) string {
	r.Contents = form["contents"]
	return "ok"
}

func (r *TestData) Get(url string) string{
	return url + " -> " + r.Contents
}

func (r *TestData) SayHello(name string) string{
	fmt.Println("Say Hello :" + name)
	return name
}

