package main

import (
	"fmt"
	"shadow/interface/mock"
	"shadow/interface/practical"
	"time"
)

type Retriever interface {
	Get(url string) string
}

type Poster interface {
	Post(url string, form map[string]string) string
}

//combination
type Combination interface {
	Retriever
	Poster
	SayHello(name string) string
}


func download(r Retriever) string{
	return r.Get("http://www.baidu.com")
}

func post(p Poster) string{
	return p.Post("http://www.baidu.com", map[string]string{
		"name": "shadow",
		"age": "30",
	})
}

func combination(com Combination){
	fmt.Println(com.Post("http://www.baidu.com", map[string]string{
		"contents": "canon",
	}))
	fmt.Println(com.Get("http://www.baidu.com"))
	com.SayHello("haha")
}


func main() {
	var r Retriever
	//接口由使用者定义，实现者的代码只需要实现一个方法即可，没有使用到使用者定义的任何类型
	r = &mock.TestData{Contents: "shadow"}
	//r = &mock.TestData{Contents: "shadow"}   值接收者，这样也是可以的。后面的switch打印不出内容，因为值已经变成指针了
	fmt.Println(download(r))
	//查看接口的实现，发现一个类型Type，一个值Value(可能是值，也可能是指针)
	fmt.Printf("%T %v\n", r, r)
	switchInterface(r)
	//Type Assertion
	fmt.Println(r)
	r2 := r.(*mock.TestData)
	fmt.Println(r2, r2.Contents)

	//实现的方法上加了指针，取地址？赋值
	r = &practical.Downloader{Agent: "qd", TimeOut: time.Minute}
	//fmt.Println(download(r))
	fmt.Printf("%T %v\n", r, r)
	switchInterface(r)

	//Type Assertion
	fmt.Println(r)
	r1 := r.(*practical.Downloader)
	fmt.Println(r1, r1.Agent)

	// 接口的组合   当接收者是值接受者时，数据并不会发生改变，统一改成指针接受者
	com := &mock.TestData{Contents: "shadow"}
	combination(com)
	// 注意两者的区别  String接口方法要求接收者是指针
	fmt.Println(com, mock.TestData{Contents: "canon"})
}

func switchInterface(r Retriever){
	fmt.Println(r)
	switch i := r.(type) {
	case *mock.TestData:
		fmt.Println(i.Contents)
	case *practical.Downloader:
		fmt.Println(i.Agent)
	}
}