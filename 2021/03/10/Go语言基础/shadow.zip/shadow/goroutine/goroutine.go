package main

import (
	"fmt"
	"runtime"
	"time"
)

func main() {
	var a [10]int
	for i := 0; i < 10; i++{
		go func(i int) {
			for{
				//fmt.Printf("goroutine %d \n", i)  I/O操作会引起协程交出控制权
				a[i]++
				runtime.Gosched()   //主动让出控制权，让其他人有机会运行，一般不这么用
			}
		}(i)
	}
	time.Sleep(time.Microsecond)   //并发执行，main退出，goroutine也会被杀掉，所以需要停一下
	fmt.Println(a)

	//raceCondition()
}

//race condition
func raceCondition(){
	var a [10]int
	for i := 0; i < 10; i++{
		//函数中引用了外部的i，但是i一直在增长，当增长到10时，发生数组越界
		go func() {
			for{
				a[i]++
				runtime.Gosched()
			}
		}()
	}
	time.Sleep(time.Microsecond)
	fmt.Println(a)
}
