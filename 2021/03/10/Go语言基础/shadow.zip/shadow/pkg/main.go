package main

import (
	"fmt"
	"shadow/pkg/queue"
)

type myQueue struct {
	queue *queue.Queue
}

func (my *myQueue) popTail() string{
	q := my.queue
	tail := (*q)[len(*q)-1]
	*q = (*q)[:len(*q)-1]
	return tail.(string)  //转换成interface{}后，需要拿出其中的值出来
}

func main(){
	q := queue.Queue{"shadow"}
	q.Push("qd")
	q.Push("shandong")
	q.Push("china")
	fmt.Println(q.Pop())
	//采用组合的方式，包装queue扩展方法
	my := myQueue{&q}
	fmt.Println(my.popTail())
}
