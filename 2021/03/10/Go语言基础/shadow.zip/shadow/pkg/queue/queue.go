package queue

type Queue []interface{}   //使用了一种通用类型  []string

func (queue *Queue) Push(value string){
	*queue = append(*queue, value)
}

func (queue *Queue) Pop() string{
	head := (*queue)[0]
	*queue = (*queue)[1:]
	return head.(string)   //转换成interface{}后，需要拿出其中的值出来
}

