package test

import "testing"

func TestSubstr(t *testing.T) {
	tests := []struct{s string; length int}{
		{"大头彬", 3},
		{"黑灰化肥灰会挥发发灰黑讳为黑灰花会飞", 7},
		{"", 0},
	}

	for _, v := range tests{
		if actual := lengthOfNonRepeatingSubStr(v.s); actual != v.length{
			t.Errorf("expected %d , but got %d", v.length, actual)
		}
	}
}

//使用Benchmark关键字进行性能测试
func BenchmarkSubstr(b *testing.B) {
	s := "黑灰化肥灰会挥发发灰黑讳为黑灰花会飞"
	length := 7
	for i := 0; i < b.N; i++ {
		actual := lengthOfNonRepeatingSubStr(s)
		if actual != length{
			b.Errorf("expected %d , but got %d", length, actual)
		}
	}
}
