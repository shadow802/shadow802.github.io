package test

import (
	"testing"
)

//测试文件编写：
//文件名采用xxx_test
//方法名写Test开头，参数为*testing.T
func TestTriangle(t *testing.T) {
	tests := []struct{ a,b,c int}{
		{3,4,5},
		{6,8,10},
		{8,15,17},
	}

	for _,v := range tests{
		if actual := triangle(v.a, v.b); actual != v.c {
			t.Errorf("expected %d, but got %d", v.c, actual)
		}
	}

}
