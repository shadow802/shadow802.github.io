package main

import (
	"fmt"
)

type treeNode struct{
	name string
	left,right *treeNode
}

func createTreeNode(name string) *treeNode{
	return &treeNode{name, nil, nil}
}

func (node treeNode) print(){
	fmt.Println(node.name)
}

func (node treeNode) setName1(name string){
	node.name = name
}

func (node *treeNode) setName2(name string){
	node.name = name
}

func (node *treeNode) traverse1(){
	if node == nil{
		return
	}
	node.left.traverse1()
	node.print()
	node.right.traverse1()
}

func (node *treeNode) traverse2(f func(node *treeNode)){
	if node == nil{
		return
	}
	node.left.traverse2(f)
	f(node)
	node.right.traverse2(f)
}

func main() {

	//实例化结构体
	var node treeNode
	root := treeNode{"shadow", nil, nil}
	fmt.Println(root, node)
	root.left = new(treeNode)
	root.right = &treeNode{"qd", nil, nil}
	root.right.left = createTreeNode("aa")


	nodes := []treeNode{
		{"china", nil, nil},
		{"shandong", nil, &root},
	}
	fmt.Println(nodes)

	//构造函数   通过定义方法来定义构造函数
	node1 := createTreeNode("ss")
	fmt.Println(node1.name)

	//方法定义   值传递、引用传递
	node2 := createTreeNode("name")
	node2.setName1("value")
	fmt.Println(node2)
	node2.setName2("value")
	fmt.Println(node2)

	//遍历
	root.traverse1()
	//使用函数式编程优化遍历要做的事情
	count := 0
	fmt.Println("------------------------")
	root.traverse2(func(node *treeNode) {
		node.print()
		count++
	})
	fmt.Println(count)


}
