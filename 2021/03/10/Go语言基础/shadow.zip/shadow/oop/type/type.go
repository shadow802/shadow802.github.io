package main

import "fmt"

//本质和string是一样的，可以强转
type test string

func (t test) Error() string{
	return string(t)     //将Test类型转换成string
}

func main() {
	x := test("xxx")     //type对象实例化方式
	fmt.Println(x)
	fmt.Println(x.Error())
}
