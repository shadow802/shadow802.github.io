package main

import "fmt"

var ss = "xxx"

func main() {
	ss := "aaa"
	var1, var2 := 3, "shadow"
	fmt.Println("go practice")
	fmt.Println(ss)
	fmt.Println(var1, var2)

	invoke()

	pointer()

	a, b := 3, 4
	swap(&a, &b)
	fmt.Println(a, b)
	//array 数组
	array()
	//slice 切片
	slice()
	//map
	mapOps()
	//rune
	runeOps()
}

func invoke(){
	var (
		name, age = "shadow", 23
		sex = "female"
	)
	fmt.Printf("%d %s %s\n", age, name, sex)

}

func pointer(){
	var a int = 3
	var x *int = &a
	*x = 4
	fmt.Printf("*x=%d\n",*x)
	fmt.Printf("a=%d\n",a)
}

func swap(a, b *int){
	fmt.Println(a, b)
	//通过内部变量，拷贝复制？先计算*b的值，记作v1，再计算*a的值记作v2，然后分别复制给*a, *b
	*a, *b = *b, *a
	fmt.Println(a, b)
}

func array(){
	var arr1 = [...]int{1,2}
	fmt.Println(arr1)

	arr2 := [2]int{3,4}
	fmt.Println(arr2)

	var arr3 [3]int
	fmt.Println(arr3)

	for i, v := range arr2{
		fmt.Println(i, arr2[i], v)
	}
}

func slice(){
	array1 := [3]int{1,2,3}
	array := [...]int{0,1,2,3,4,5,6,7,8,9}
	//使用array传参，数组内数据无变化
	arrayParam(array)
	//arrayParam(array1)  编译错误，不同个数的数组是不同的类型
	fmt.Println(array, array1)
	//使用slice传参，数组发生变化
	arraySlice(array[:])
	arraySlice(array1[:1])
	fmt.Println(array, array1)

	//slice 创建
	slice1 := make([]int, 2, 4)   //后面两个参数是len和cap
	fmt.Println(slice1, len(slice1), cap(slice1))

	var sliceNull []int
	fmt.Println(sliceNull == nil)   // Zero value


	slice2 := array[2:5]
	fmt.Println(array)
	fmt.Println(slice2, len(slice2), cap(slice2))
	//fmt.Println(slice2[3])   使用下标的方式取越界的数据，运行时会报异常
	slice3 := slice2[2:5]
	fmt.Println(slice3, len(slice3), cap(slice3))        //通过越界slice2 len的方式进一步切片，取到了原始数组后面的数据

	//slice 元素添加
	// 在不超过原数组array的cap的情况下，覆盖后面的值进行添加
	slice4 := append(slice3,10,11,12)
	fmt.Println(slice4, len(slice4), cap(slice4))
	fmt.Println(array, len(array), cap(array))
	// 如果超过了cap，原数组array不会发生改变，系统会为slice5申请生成新的底层数组，不再是array的视图
	slice5 := append(slice3,10,11,12,13,14,15)
	fmt.Println(slice5, len(slice5), cap(slice5))
	fmt.Println(array, len(array), cap(array))

	//slice 复制
	var slice6 []int
	copy(slice6, array[:])
	// nil 不能复制
	fmt.Println(array, slice6)
	slice7 := make([]int, 2, 2)
	copy(slice7, array[:])
	// 目标数组len不够，不会自动扩展
	fmt.Println(array, slice7)

	slice8 := make([]int, 12, 12)
	copy(slice8, array[:])
	fmt.Println(array, slice8)

	//slice 元素删除
	slice9 := array[1:]
	slice10 := slice9[:len(slice9)-1]
	slice11 := append(slice10[:2], slice10[3:]...)
	fmt.Println(array, slice9, slice10, slice11)
}

func arrayParam(array [10]int){
	array[0] = 999
	for i, v := range array{
		fmt.Println(i, v)
	}
}

func arraySlice(array []int){
	array[0] = 999
	for i, v := range array{
		fmt.Println(i, v)
	}
}

func mapOps(){
	//map 的定义
	map1 := map[string]string{
		"name": "shadow",
		"age": "32",
	}
	var map2 map[string]int
	fmt.Println(map1, map2)

	//map 遍历
	for k, v := range map1{
		fmt.Println(k, v)
	}

	//map 取值
	if v, ok := map1["name"]; ok{
		fmt.Println(v)
	}else{
		fmt.Println("no exists")
	}

	//map 删除
	delete(map1, "age")
	fmt.Println(map1)
}

func runeOps(){
	s := "ss青岛市崂山区国际创新园ss"
	for i, r := range s{
		fmt.Println(i, r)
	}

	for i, v := range []byte(s){
		fmt.Printf("(%d, %X)", i, v)
	}
	fmt.Println()
	for i, v := range s{
		fmt.Printf("(%d, %X)", i, v)
	}
	fmt.Println()

}