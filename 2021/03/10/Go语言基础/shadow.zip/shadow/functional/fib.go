package main

import (
	"bufio"
	"fmt"
	"io"
	"strings"
)

//从 1、1、2、3 开始，后面一个数等于前两个数的相加
func fibonacci() fibGen{
	pre1, pre2 := 0, 1
	return func() int {
		pre1, pre2 = pre2, pre1 + pre2
		return pre1
	}
}

type fibGen func() int

//为一个函数类型增加接口实现，就可以使用这个类型作为这个接口的一个实现。类型可以支持实现多个接口
func (f fibGen) Read(p []byte) (n int, err error) {
	next := f()
	if next > 10000{
		return 0, io.EOF
	}
	s := fmt.Sprintf("%d\n", next)

	//TODO if p is too small has errors
	return strings.NewReader(s).Read(p)
}

func readFib(read io.Reader){
	scan := bufio.NewScanner(read)
	for scan.Scan(){
		fmt.Println(scan.Text())
	}
}

func main() {
	//返回一个函数
	f := fibonacci()
	for i:=0; i<9; i++{
		//调用返回的函数
		fmt.Println(f())
	}
	//将返回的函数作为Reader的接口实现传入进去
	readFib(f)
}
