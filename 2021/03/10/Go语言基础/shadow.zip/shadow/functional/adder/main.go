package main

import "fmt"

func adder() func(i int) int{
	sum := 0  //sum 自由变量
	return func(i int) int {
		sum += i // i 局部变量
		return sum
	}
}

//正统的函数式编程，不能有状态
type iAdder func(i int) (int, iAdder)

func adder1(base int) iAdder{
	fmt.Printf("base=%d\n", base)
	return func(i int) (int, iAdder) {
		fmt.Printf("i=%d\n", i)
		return base+i, adder1(base+i)  //这里 有对base值的更新
	}
}


func main() {
	adder := adder()

	for i:=1; i<10; i++{
		fmt.Println(adder(i))
	}

	f := adder1(0)
	for i:=1; i<10; i++{
		var s int
		s, f = f(i)
		fmt.Println(s)
	}

}
