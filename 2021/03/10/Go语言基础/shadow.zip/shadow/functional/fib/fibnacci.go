package fib

//从 1、1、2、3 开始，后面一个数等于前两个数的相加
func Fibonacci() func() uint64 {
	pre1, pre2 := 0, 1
	return func() uint64 {
		pre1, pre2 = pre2, pre1 + pre2
		return uint64(pre1)
	}
}
